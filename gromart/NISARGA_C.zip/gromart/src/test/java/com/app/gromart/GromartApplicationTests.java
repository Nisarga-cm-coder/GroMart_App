package com.app.gromart;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GromartApplicationTests {

	@Test
	void contextLoads() {
	}

}
